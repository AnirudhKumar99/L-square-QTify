import React from 'react';
import RightArrowIcon from '../assets/test.png'
import './CarouselButton.css';

function RightArrowButton() {
  return (
    <img src={RightArrowIcon} alt="Next"  />
  );
}

export default RightArrowButton;