import React from "react";
import "swiper/swiper-bundle.css";
import AlbumCard from "./AlbumCard";
import "./Carousel.css";
import LeftArrowButton from "./LeftArrowButton";
import RightArrowButton from "./RightArrowButton";
import { Swiper, SwiperSlide } from "swiper/react";
function Carousel({ albums }) {
  const params = {
    slidesPerView: 5,
    spaceBetween: 20,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
      disabledClass: "swiper-button-disabled",
    },
    breakpoints: {
      320: {
        slidesPerView: 1,
      },
      640: {
        slidesPerView: 2,
      },
      992: {
        slidesPerView: 3,
      },
      1200: {
        slidesPerView: 4,
      },
      1400: {
        slidesPerView: 5,
      },
    },
  };

  return (
    <div className="carousel-container">
      <Swiper {...params}>
        {albums.map((album) => (
          <SwiperSlide key={album.id}>
            <AlbumCard album={album} />
          </SwiperSlide>
        ))}
      </Swiper>
      <div className="swiper-buttons">
        <div className="swiper-button-prev">
          <LeftArrowButton />
        </div>
        <div className="swiper-button-next">
          <RightArrowButton />
        </div>
      </div>
    </div>
  );
}

export default Carousel;
