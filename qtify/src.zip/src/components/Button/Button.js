import React from 'react';
import './Button.css';

function FeedbackButton() {
  return (
    <button className="feedback-button">Give Feedback</button>
  );
}

export default FeedbackButton;