// import React, { useState, useEffect } from 'react';
// import AlbumCard from './AlbumCard';
// import axios from 'axios';
// import './Section.css';

// function Section({ title, apiUrl }) {
//   const [albums, setAlbums] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [showAll, setShowAll] = useState(false);
//   const displayedAlbums = showAll ? albums : albums.slice(0, 6); // Show first 6 or all

//   useEffect(() => {
//     const fetchAlbums = async () => {
//       try {
//         const response = await axios.get(apiUrl);
//         setAlbums(response.data);
//         setLoading(false);
//       } catch (error) {
//         console.error('Error fetching albums:', error);
//         setError('Failed to load albums.');
//         setLoading(false);
//       }
//     };

//     fetchAlbums();
//   }, [apiUrl]);

//   const toggleShowAll = () => {
//     setShowAll(!showAll);
//   };

//   if (loading) {
//     return <p>Loading {title}...</p>;
//   }

//   if (error) {
//     return <p className="error-message">{error}</p>;
//   }

//   return (
//     <div className="section-container">
//       <div className="section-header">
//         <h2>{title}</h2>
//         {albums.length > 6 && (
//           <button className="collapse-button" onClick={toggleShowAll}>
//             {showAll ? 'Collapse' : 'Show All'}
//           </button>
//         )}
//       </div>
//       <div className="albums-grid">
//         {displayedAlbums.map((album) => (
//           <AlbumCard key={album.id} album={album} />
//         ))}
//       </div>
//     </div>
//   );
// }

// export default Section;
import React, { useState, useEffect } from 'react';
import AlbumCard from './AlbumCard';
import Carousel from './Carousel';
import axios from 'axios';
import './Section.css';


function Section({ title, apiUrl }) {
  const [albums, setAlbums] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    const fetchAlbums = async () => {
      try {
        const response = await axios.get(apiUrl);
        setAlbums(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching albums:', error);
        setError('Failed to load albums.');
        setLoading(false);
      }
    };

    fetchAlbums();
  }, [apiUrl]);

  const toggleShowAll = () => {
    setShowAll(!showAll);
  };

  if (loading) {
    return <p>Loading {title}...</p>;
  }

  if (error) {
    return <p className="error-message">{error}</p>;
  }
  return (
    <div className="section-container">
      <div className="section-header">
        <h2>{title}</h2>
        {albums.length > 6 && (
          <button className="collapse-button" onClick={toggleShowAll}>
            {showAll ? 'Show All' : 'Collapse'}
          </button>
        )}
      </div>
      {showAll  ? (
        <Carousel albums={albums} />
      ) : (
        <div className="albums-grid">
          {albums.slice(0, 6).map((album) => (
            <AlbumCard key={album.id} album={album} />
          ))}
        </div>
      )}
    </div>
  );
}

export default Section;