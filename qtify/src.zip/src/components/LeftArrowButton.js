import React from 'react';
import LeftArrowIcon from '../assets/left-arrow.svg';
import './CarouselButton.css';

function LeftArrowButton() {
  return (
    <img src={LeftArrowIcon} alt="Previous" className="carousel-button" />
  );
}

export default LeftArrowButton;